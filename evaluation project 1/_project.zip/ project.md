```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import warnings 
warnings.filterwarnings('ignore')
```


```python
import os
```


```python
os.getcwd()
```




    'C:\\Users\\Laksh'




```python
os.chdir("C:\\Users\\Laksh\\Downloads")
```


```python
df = pd.read_csv("C:\\Users\\Laksh\\Downloads\\baseball.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>W</th>
      <th>R</th>
      <th>AB</th>
      <th>H</th>
      <th>2B</th>
      <th>3B</th>
      <th>HR</th>
      <th>BB</th>
      <th>SO</th>
      <th>SB</th>
      <th>RA</th>
      <th>ER</th>
      <th>ERA</th>
      <th>CG</th>
      <th>SHO</th>
      <th>SV</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>95</td>
      <td>724</td>
      <td>5575</td>
      <td>1497</td>
      <td>300</td>
      <td>42</td>
      <td>139</td>
      <td>383</td>
      <td>973</td>
      <td>104</td>
      <td>641</td>
      <td>601</td>
      <td>3.73</td>
      <td>2</td>
      <td>8</td>
      <td>56</td>
      <td>88</td>
    </tr>
    <tr>
      <th>1</th>
      <td>83</td>
      <td>696</td>
      <td>5467</td>
      <td>1349</td>
      <td>277</td>
      <td>44</td>
      <td>156</td>
      <td>439</td>
      <td>1264</td>
      <td>70</td>
      <td>700</td>
      <td>653</td>
      <td>4.07</td>
      <td>2</td>
      <td>12</td>
      <td>45</td>
      <td>86</td>
    </tr>
    <tr>
      <th>2</th>
      <td>81</td>
      <td>669</td>
      <td>5439</td>
      <td>1395</td>
      <td>303</td>
      <td>29</td>
      <td>141</td>
      <td>533</td>
      <td>1157</td>
      <td>86</td>
      <td>640</td>
      <td>584</td>
      <td>3.67</td>
      <td>11</td>
      <td>10</td>
      <td>38</td>
      <td>79</td>
    </tr>
    <tr>
      <th>3</th>
      <td>76</td>
      <td>622</td>
      <td>5533</td>
      <td>1381</td>
      <td>260</td>
      <td>27</td>
      <td>136</td>
      <td>404</td>
      <td>1231</td>
      <td>68</td>
      <td>701</td>
      <td>643</td>
      <td>3.98</td>
      <td>7</td>
      <td>9</td>
      <td>37</td>
      <td>101</td>
    </tr>
    <tr>
      <th>4</th>
      <td>74</td>
      <td>689</td>
      <td>5605</td>
      <td>1515</td>
      <td>289</td>
      <td>49</td>
      <td>151</td>
      <td>455</td>
      <td>1259</td>
      <td>83</td>
      <td>803</td>
      <td>746</td>
      <td>4.64</td>
      <td>7</td>
      <td>12</td>
      <td>35</td>
      <td>86</td>
    </tr>
    <tr>
      <th>5</th>
      <td>93</td>
      <td>891</td>
      <td>5509</td>
      <td>1480</td>
      <td>308</td>
      <td>17</td>
      <td>232</td>
      <td>570</td>
      <td>1151</td>
      <td>88</td>
      <td>670</td>
      <td>609</td>
      <td>3.80</td>
      <td>7</td>
      <td>10</td>
      <td>34</td>
      <td>88</td>
    </tr>
    <tr>
      <th>6</th>
      <td>87</td>
      <td>764</td>
      <td>5567</td>
      <td>1397</td>
      <td>272</td>
      <td>19</td>
      <td>212</td>
      <td>554</td>
      <td>1227</td>
      <td>63</td>
      <td>698</td>
      <td>652</td>
      <td>4.03</td>
      <td>3</td>
      <td>4</td>
      <td>48</td>
      <td>93</td>
    </tr>
    <tr>
      <th>7</th>
      <td>81</td>
      <td>713</td>
      <td>5485</td>
      <td>1370</td>
      <td>246</td>
      <td>20</td>
      <td>217</td>
      <td>418</td>
      <td>1331</td>
      <td>44</td>
      <td>693</td>
      <td>646</td>
      <td>4.05</td>
      <td>0</td>
      <td>10</td>
      <td>43</td>
      <td>77</td>
    </tr>
    <tr>
      <th>8</th>
      <td>80</td>
      <td>644</td>
      <td>5485</td>
      <td>1383</td>
      <td>278</td>
      <td>32</td>
      <td>167</td>
      <td>436</td>
      <td>1310</td>
      <td>87</td>
      <td>642</td>
      <td>604</td>
      <td>3.74</td>
      <td>1</td>
      <td>12</td>
      <td>60</td>
      <td>95</td>
    </tr>
    <tr>
      <th>9</th>
      <td>78</td>
      <td>748</td>
      <td>5640</td>
      <td>1495</td>
      <td>294</td>
      <td>33</td>
      <td>161</td>
      <td>478</td>
      <td>1148</td>
      <td>71</td>
      <td>753</td>
      <td>694</td>
      <td>4.31</td>
      <td>3</td>
      <td>10</td>
      <td>40</td>
      <td>97</td>
    </tr>
    <tr>
      <th>10</th>
      <td>88</td>
      <td>751</td>
      <td>5511</td>
      <td>1419</td>
      <td>279</td>
      <td>32</td>
      <td>172</td>
      <td>503</td>
      <td>1233</td>
      <td>101</td>
      <td>733</td>
      <td>680</td>
      <td>4.24</td>
      <td>5</td>
      <td>9</td>
      <td>45</td>
      <td>119</td>
    </tr>
    <tr>
      <th>11</th>
      <td>86</td>
      <td>729</td>
      <td>5459</td>
      <td>1363</td>
      <td>278</td>
      <td>26</td>
      <td>230</td>
      <td>486</td>
      <td>1392</td>
      <td>121</td>
      <td>618</td>
      <td>572</td>
      <td>3.57</td>
      <td>5</td>
      <td>13</td>
      <td>39</td>
      <td>85</td>
    </tr>
    <tr>
      <th>12</th>
      <td>85</td>
      <td>661</td>
      <td>5417</td>
      <td>1331</td>
      <td>243</td>
      <td>21</td>
      <td>176</td>
      <td>435</td>
      <td>1150</td>
      <td>52</td>
      <td>675</td>
      <td>630</td>
      <td>3.94</td>
      <td>2</td>
      <td>12</td>
      <td>46</td>
      <td>93</td>
    </tr>
    <tr>
      <th>13</th>
      <td>76</td>
      <td>656</td>
      <td>5544</td>
      <td>1379</td>
      <td>262</td>
      <td>22</td>
      <td>198</td>
      <td>478</td>
      <td>1336</td>
      <td>69</td>
      <td>726</td>
      <td>677</td>
      <td>4.16</td>
      <td>6</td>
      <td>12</td>
      <td>45</td>
      <td>94</td>
    </tr>
    <tr>
      <th>14</th>
      <td>68</td>
      <td>694</td>
      <td>5600</td>
      <td>1405</td>
      <td>277</td>
      <td>46</td>
      <td>146</td>
      <td>475</td>
      <td>1119</td>
      <td>78</td>
      <td>729</td>
      <td>664</td>
      <td>4.14</td>
      <td>5</td>
      <td>15</td>
      <td>28</td>
      <td>126</td>
    </tr>
    <tr>
      <th>15</th>
      <td>100</td>
      <td>647</td>
      <td>5484</td>
      <td>1386</td>
      <td>288</td>
      <td>39</td>
      <td>137</td>
      <td>506</td>
      <td>1267</td>
      <td>69</td>
      <td>525</td>
      <td>478</td>
      <td>2.94</td>
      <td>1</td>
      <td>15</td>
      <td>62</td>
      <td>96</td>
    </tr>
    <tr>
      <th>16</th>
      <td>98</td>
      <td>697</td>
      <td>5631</td>
      <td>1462</td>
      <td>292</td>
      <td>27</td>
      <td>140</td>
      <td>461</td>
      <td>1322</td>
      <td>98</td>
      <td>596</td>
      <td>532</td>
      <td>3.21</td>
      <td>0</td>
      <td>13</td>
      <td>54</td>
      <td>122</td>
    </tr>
    <tr>
      <th>17</th>
      <td>97</td>
      <td>689</td>
      <td>5491</td>
      <td>1341</td>
      <td>272</td>
      <td>30</td>
      <td>171</td>
      <td>567</td>
      <td>1518</td>
      <td>95</td>
      <td>608</td>
      <td>546</td>
      <td>3.36</td>
      <td>6</td>
      <td>21</td>
      <td>48</td>
      <td>111</td>
    </tr>
    <tr>
      <th>18</th>
      <td>68</td>
      <td>655</td>
      <td>5480</td>
      <td>1378</td>
      <td>274</td>
      <td>34</td>
      <td>145</td>
      <td>412</td>
      <td>1299</td>
      <td>84</td>
      <td>737</td>
      <td>682</td>
      <td>4.28</td>
      <td>1</td>
      <td>7</td>
      <td>40</td>
      <td>116</td>
    </tr>
    <tr>
      <th>19</th>
      <td>64</td>
      <td>640</td>
      <td>5571</td>
      <td>1382</td>
      <td>257</td>
      <td>27</td>
      <td>167</td>
      <td>496</td>
      <td>1255</td>
      <td>134</td>
      <td>754</td>
      <td>700</td>
      <td>4.33</td>
      <td>2</td>
      <td>8</td>
      <td>35</td>
      <td>90</td>
    </tr>
    <tr>
      <th>20</th>
      <td>90</td>
      <td>683</td>
      <td>5527</td>
      <td>1351</td>
      <td>295</td>
      <td>17</td>
      <td>177</td>
      <td>488</td>
      <td>1290</td>
      <td>51</td>
      <td>613</td>
      <td>557</td>
      <td>3.43</td>
      <td>1</td>
      <td>14</td>
      <td>50</td>
      <td>88</td>
    </tr>
    <tr>
      <th>21</th>
      <td>83</td>
      <td>703</td>
      <td>5428</td>
      <td>1363</td>
      <td>265</td>
      <td>13</td>
      <td>177</td>
      <td>539</td>
      <td>1344</td>
      <td>57</td>
      <td>635</td>
      <td>577</td>
      <td>3.62</td>
      <td>4</td>
      <td>13</td>
      <td>41</td>
      <td>90</td>
    </tr>
    <tr>
      <th>22</th>
      <td>71</td>
      <td>613</td>
      <td>5463</td>
      <td>1420</td>
      <td>236</td>
      <td>40</td>
      <td>120</td>
      <td>375</td>
      <td>1150</td>
      <td>112</td>
      <td>678</td>
      <td>638</td>
      <td>4.02</td>
      <td>0</td>
      <td>12</td>
      <td>35</td>
      <td>77</td>
    </tr>
    <tr>
      <th>23</th>
      <td>67</td>
      <td>573</td>
      <td>5420</td>
      <td>1361</td>
      <td>251</td>
      <td>18</td>
      <td>100</td>
      <td>471</td>
      <td>1107</td>
      <td>69</td>
      <td>760</td>
      <td>698</td>
      <td>4.41</td>
      <td>3</td>
      <td>10</td>
      <td>44</td>
      <td>90</td>
    </tr>
    <tr>
      <th>24</th>
      <td>63</td>
      <td>626</td>
      <td>5529</td>
      <td>1374</td>
      <td>272</td>
      <td>37</td>
      <td>130</td>
      <td>387</td>
      <td>1274</td>
      <td>88</td>
      <td>809</td>
      <td>749</td>
      <td>4.69</td>
      <td>1</td>
      <td>7</td>
      <td>35</td>
      <td>117</td>
    </tr>
    <tr>
      <th>25</th>
      <td>92</td>
      <td>667</td>
      <td>5385</td>
      <td>1346</td>
      <td>263</td>
      <td>26</td>
      <td>187</td>
      <td>563</td>
      <td>1258</td>
      <td>59</td>
      <td>595</td>
      <td>553</td>
      <td>3.44</td>
      <td>6</td>
      <td>21</td>
      <td>47</td>
      <td>75</td>
    </tr>
    <tr>
      <th>26</th>
      <td>84</td>
      <td>696</td>
      <td>5565</td>
      <td>1486</td>
      <td>288</td>
      <td>39</td>
      <td>136</td>
      <td>457</td>
      <td>1159</td>
      <td>93</td>
      <td>627</td>
      <td>597</td>
      <td>3.72</td>
      <td>7</td>
      <td>18</td>
      <td>41</td>
      <td>78</td>
    </tr>
    <tr>
      <th>27</th>
      <td>79</td>
      <td>720</td>
      <td>5649</td>
      <td>1494</td>
      <td>289</td>
      <td>48</td>
      <td>154</td>
      <td>490</td>
      <td>1312</td>
      <td>132</td>
      <td>713</td>
      <td>659</td>
      <td>4.04</td>
      <td>1</td>
      <td>12</td>
      <td>44</td>
      <td>86</td>
    </tr>
    <tr>
      <th>28</th>
      <td>74</td>
      <td>650</td>
      <td>5457</td>
      <td>1324</td>
      <td>260</td>
      <td>36</td>
      <td>148</td>
      <td>426</td>
      <td>1327</td>
      <td>82</td>
      <td>731</td>
      <td>655</td>
      <td>4.09</td>
      <td>1</td>
      <td>6</td>
      <td>41</td>
      <td>92</td>
    </tr>
    <tr>
      <th>29</th>
      <td>68</td>
      <td>737</td>
      <td>5572</td>
      <td>1479</td>
      <td>274</td>
      <td>49</td>
      <td>186</td>
      <td>388</td>
      <td>1283</td>
      <td>97</td>
      <td>844</td>
      <td>799</td>
      <td>5.04</td>
      <td>4</td>
      <td>4</td>
      <td>36</td>
      <td>95</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>W</th>
      <th>R</th>
      <th>AB</th>
      <th>H</th>
      <th>2B</th>
      <th>3B</th>
      <th>HR</th>
      <th>BB</th>
      <th>SO</th>
      <th>SB</th>
      <th>RA</th>
      <th>ER</th>
      <th>ERA</th>
      <th>CG</th>
      <th>SHO</th>
      <th>SV</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>95</td>
      <td>724</td>
      <td>5575</td>
      <td>1497</td>
      <td>300</td>
      <td>42</td>
      <td>139</td>
      <td>383</td>
      <td>973</td>
      <td>104</td>
      <td>641</td>
      <td>601</td>
      <td>3.73</td>
      <td>2</td>
      <td>8</td>
      <td>56</td>
      <td>88</td>
    </tr>
    <tr>
      <th>1</th>
      <td>83</td>
      <td>696</td>
      <td>5467</td>
      <td>1349</td>
      <td>277</td>
      <td>44</td>
      <td>156</td>
      <td>439</td>
      <td>1264</td>
      <td>70</td>
      <td>700</td>
      <td>653</td>
      <td>4.07</td>
      <td>2</td>
      <td>12</td>
      <td>45</td>
      <td>86</td>
    </tr>
    <tr>
      <th>2</th>
      <td>81</td>
      <td>669</td>
      <td>5439</td>
      <td>1395</td>
      <td>303</td>
      <td>29</td>
      <td>141</td>
      <td>533</td>
      <td>1157</td>
      <td>86</td>
      <td>640</td>
      <td>584</td>
      <td>3.67</td>
      <td>11</td>
      <td>10</td>
      <td>38</td>
      <td>79</td>
    </tr>
    <tr>
      <th>3</th>
      <td>76</td>
      <td>622</td>
      <td>5533</td>
      <td>1381</td>
      <td>260</td>
      <td>27</td>
      <td>136</td>
      <td>404</td>
      <td>1231</td>
      <td>68</td>
      <td>701</td>
      <td>643</td>
      <td>3.98</td>
      <td>7</td>
      <td>9</td>
      <td>37</td>
      <td>101</td>
    </tr>
    <tr>
      <th>4</th>
      <td>74</td>
      <td>689</td>
      <td>5605</td>
      <td>1515</td>
      <td>289</td>
      <td>49</td>
      <td>151</td>
      <td>455</td>
      <td>1259</td>
      <td>83</td>
      <td>803</td>
      <td>746</td>
      <td>4.64</td>
      <td>7</td>
      <td>12</td>
      <td>35</td>
      <td>86</td>
    </tr>
    <tr>
      <th>5</th>
      <td>93</td>
      <td>891</td>
      <td>5509</td>
      <td>1480</td>
      <td>308</td>
      <td>17</td>
      <td>232</td>
      <td>570</td>
      <td>1151</td>
      <td>88</td>
      <td>670</td>
      <td>609</td>
      <td>3.80</td>
      <td>7</td>
      <td>10</td>
      <td>34</td>
      <td>88</td>
    </tr>
    <tr>
      <th>6</th>
      <td>87</td>
      <td>764</td>
      <td>5567</td>
      <td>1397</td>
      <td>272</td>
      <td>19</td>
      <td>212</td>
      <td>554</td>
      <td>1227</td>
      <td>63</td>
      <td>698</td>
      <td>652</td>
      <td>4.03</td>
      <td>3</td>
      <td>4</td>
      <td>48</td>
      <td>93</td>
    </tr>
    <tr>
      <th>7</th>
      <td>81</td>
      <td>713</td>
      <td>5485</td>
      <td>1370</td>
      <td>246</td>
      <td>20</td>
      <td>217</td>
      <td>418</td>
      <td>1331</td>
      <td>44</td>
      <td>693</td>
      <td>646</td>
      <td>4.05</td>
      <td>0</td>
      <td>10</td>
      <td>43</td>
      <td>77</td>
    </tr>
    <tr>
      <th>8</th>
      <td>80</td>
      <td>644</td>
      <td>5485</td>
      <td>1383</td>
      <td>278</td>
      <td>32</td>
      <td>167</td>
      <td>436</td>
      <td>1310</td>
      <td>87</td>
      <td>642</td>
      <td>604</td>
      <td>3.74</td>
      <td>1</td>
      <td>12</td>
      <td>60</td>
      <td>95</td>
    </tr>
    <tr>
      <th>9</th>
      <td>78</td>
      <td>748</td>
      <td>5640</td>
      <td>1495</td>
      <td>294</td>
      <td>33</td>
      <td>161</td>
      <td>478</td>
      <td>1148</td>
      <td>71</td>
      <td>753</td>
      <td>694</td>
      <td>4.31</td>
      <td>3</td>
      <td>10</td>
      <td>40</td>
      <td>97</td>
    </tr>
  </tbody>
</table>
</div>




```python
 df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>W</th>
      <th>R</th>
      <th>AB</th>
      <th>H</th>
      <th>2B</th>
      <th>3B</th>
      <th>HR</th>
      <th>BB</th>
      <th>SO</th>
      <th>SB</th>
      <th>RA</th>
      <th>ER</th>
      <th>ERA</th>
      <th>CG</th>
      <th>SHO</th>
      <th>SV</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>95</td>
      <td>724</td>
      <td>5575</td>
      <td>1497</td>
      <td>300</td>
      <td>42</td>
      <td>139</td>
      <td>383</td>
      <td>973</td>
      <td>104</td>
      <td>641</td>
      <td>601</td>
      <td>3.73</td>
      <td>2</td>
      <td>8</td>
      <td>56</td>
      <td>88</td>
    </tr>
    <tr>
      <th>1</th>
      <td>83</td>
      <td>696</td>
      <td>5467</td>
      <td>1349</td>
      <td>277</td>
      <td>44</td>
      <td>156</td>
      <td>439</td>
      <td>1264</td>
      <td>70</td>
      <td>700</td>
      <td>653</td>
      <td>4.07</td>
      <td>2</td>
      <td>12</td>
      <td>45</td>
      <td>86</td>
    </tr>
    <tr>
      <th>2</th>
      <td>81</td>
      <td>669</td>
      <td>5439</td>
      <td>1395</td>
      <td>303</td>
      <td>29</td>
      <td>141</td>
      <td>533</td>
      <td>1157</td>
      <td>86</td>
      <td>640</td>
      <td>584</td>
      <td>3.67</td>
      <td>11</td>
      <td>10</td>
      <td>38</td>
      <td>79</td>
    </tr>
    <tr>
      <th>3</th>
      <td>76</td>
      <td>622</td>
      <td>5533</td>
      <td>1381</td>
      <td>260</td>
      <td>27</td>
      <td>136</td>
      <td>404</td>
      <td>1231</td>
      <td>68</td>
      <td>701</td>
      <td>643</td>
      <td>3.98</td>
      <td>7</td>
      <td>9</td>
      <td>37</td>
      <td>101</td>
    </tr>
    <tr>
      <th>4</th>
      <td>74</td>
      <td>689</td>
      <td>5605</td>
      <td>1515</td>
      <td>289</td>
      <td>49</td>
      <td>151</td>
      <td>455</td>
      <td>1259</td>
      <td>83</td>
      <td>803</td>
      <td>746</td>
      <td>4.64</td>
      <td>7</td>
      <td>12</td>
      <td>35</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>W</th>
      <th>R</th>
      <th>AB</th>
      <th>H</th>
      <th>2B</th>
      <th>3B</th>
      <th>HR</th>
      <th>BB</th>
      <th>SO</th>
      <th>SB</th>
      <th>RA</th>
      <th>ER</th>
      <th>ERA</th>
      <th>CG</th>
      <th>SHO</th>
      <th>SV</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>25</th>
      <td>92</td>
      <td>667</td>
      <td>5385</td>
      <td>1346</td>
      <td>263</td>
      <td>26</td>
      <td>187</td>
      <td>563</td>
      <td>1258</td>
      <td>59</td>
      <td>595</td>
      <td>553</td>
      <td>3.44</td>
      <td>6</td>
      <td>21</td>
      <td>47</td>
      <td>75</td>
    </tr>
    <tr>
      <th>26</th>
      <td>84</td>
      <td>696</td>
      <td>5565</td>
      <td>1486</td>
      <td>288</td>
      <td>39</td>
      <td>136</td>
      <td>457</td>
      <td>1159</td>
      <td>93</td>
      <td>627</td>
      <td>597</td>
      <td>3.72</td>
      <td>7</td>
      <td>18</td>
      <td>41</td>
      <td>78</td>
    </tr>
    <tr>
      <th>27</th>
      <td>79</td>
      <td>720</td>
      <td>5649</td>
      <td>1494</td>
      <td>289</td>
      <td>48</td>
      <td>154</td>
      <td>490</td>
      <td>1312</td>
      <td>132</td>
      <td>713</td>
      <td>659</td>
      <td>4.04</td>
      <td>1</td>
      <td>12</td>
      <td>44</td>
      <td>86</td>
    </tr>
    <tr>
      <th>28</th>
      <td>74</td>
      <td>650</td>
      <td>5457</td>
      <td>1324</td>
      <td>260</td>
      <td>36</td>
      <td>148</td>
      <td>426</td>
      <td>1327</td>
      <td>82</td>
      <td>731</td>
      <td>655</td>
      <td>4.09</td>
      <td>1</td>
      <td>6</td>
      <td>41</td>
      <td>92</td>
    </tr>
    <tr>
      <th>29</th>
      <td>68</td>
      <td>737</td>
      <td>5572</td>
      <td>1479</td>
      <td>274</td>
      <td>49</td>
      <td>186</td>
      <td>388</td>
      <td>1283</td>
      <td>97</td>
      <td>844</td>
      <td>799</td>
      <td>5.04</td>
      <td>4</td>
      <td>4</td>
      <td>36</td>
      <td>95</td>
    </tr>
  </tbody>
</table>
</div>




```python
 df.shape
```




    (30, 17)




```python
df.columns
```




    Index(['W', 'R', 'AB', 'H', '2B', '3B', 'HR', 'BB', 'SO', 'SB', 'RA', 'ER',
           'ERA', 'CG', 'SHO', 'SV', 'E'],
          dtype='object')




```python
df.columns.tolist()
```




    ['W',
     'R',
     'AB',
     'H',
     '2B',
     '3B',
     'HR',
     'BB',
     'SO',
     'SB',
     'RA',
     'ER',
     'ERA',
     'CG',
     'SHO',
     'SV',
     'E']




```python
df.dtypes
```




    W        int64
    R        int64
    AB       int64
    H        int64
    2B       int64
    3B       int64
    HR       int64
    BB       int64
    SO       int64
    SB       int64
    RA       int64
    ER       int64
    ERA    float64
    CG       int64
    SHO      int64
    SV       int64
    E        int64
    dtype: object




```python
df.isnull().sum()
```




    W      0
    R      0
    AB     0
    H      0
    2B     0
    3B     0
    HR     0
    BB     0
    SO     0
    SB     0
    RA     0
    ER     0
    ERA    0
    CG     0
    SHO    0
    SV     0
    E      0
    dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30 entries, 0 to 29
    Data columns (total 17 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   W       30 non-null     int64  
     1   R       30 non-null     int64  
     2   AB      30 non-null     int64  
     3   H       30 non-null     int64  
     4   2B      30 non-null     int64  
     5   3B      30 non-null     int64  
     6   HR      30 non-null     int64  
     7   BB      30 non-null     int64  
     8   SO      30 non-null     int64  
     9   SB      30 non-null     int64  
     10  RA      30 non-null     int64  
     11  ER      30 non-null     int64  
     12  ERA     30 non-null     float64
     13  CG      30 non-null     int64  
     14  SHO     30 non-null     int64  
     15  SV      30 non-null     int64  
     16  E       30 non-null     int64  
    dtypes: float64(1), int64(16)
    memory usage: 4.1 KB
    


```python
sns.heatmap(df.isnull())
```




    <AxesSubplot:>




    
![png](output_14_1.png)
    



```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30 entries, 0 to 29
    Data columns (total 17 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   W       30 non-null     int64  
     1   R       30 non-null     int64  
     2   AB      30 non-null     int64  
     3   H       30 non-null     int64  
     4   2B      30 non-null     int64  
     5   3B      30 non-null     int64  
     6   HR      30 non-null     int64  
     7   BB      30 non-null     int64  
     8   SO      30 non-null     int64  
     9   SB      30 non-null     int64  
     10  RA      30 non-null     int64  
     11  ER      30 non-null     int64  
     12  ERA     30 non-null     float64
     13  CG      30 non-null     int64  
     14  SHO     30 non-null     int64  
     15  SV      30 non-null     int64  
     16  E       30 non-null     int64  
    dtypes: float64(1), int64(16)
    memory usage: 4.1 KB
    


```python

df.isnull().sum()
```




    W      0
    R      0
    AB     0
    H      0
    2B     0
    3B     0
    HR     0
    BB     0
    SO     0
    SB     0
    RA     0
    ER     0
    ERA    0
    CG     0
    SHO    0
    SV     0
    E      0
    dtype: int64




```python
df.isnull().sum().sum()
```




    0




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30 entries, 0 to 29
    Data columns (total 17 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   W       30 non-null     int64  
     1   R       30 non-null     int64  
     2   AB      30 non-null     int64  
     3   H       30 non-null     int64  
     4   2B      30 non-null     int64  
     5   3B      30 non-null     int64  
     6   HR      30 non-null     int64  
     7   BB      30 non-null     int64  
     8   SO      30 non-null     int64  
     9   SB      30 non-null     int64  
     10  RA      30 non-null     int64  
     11  ER      30 non-null     int64  
     12  ERA     30 non-null     float64
     13  CG      30 non-null     int64  
     14  SHO     30 non-null     int64  
     15  SV      30 non-null     int64  
     16  E       30 non-null     int64  
    dtypes: float64(1), int64(16)
    memory usage: 4.1 KB
    


```python
for i in df.columns:
    print(df[i].value_counts())
    print('\n')
```

    68     3
    81     2
    76     2
    74     2
    83     2
    98     1
    84     1
    92     1
    63     1
    67     1
    71     1
    90     1
    64     1
    97     1
    95     1
    100    1
    85     1
    86     1
    88     1
    78     1
    80     1
    87     1
    93     1
    79     1
    Name: W, dtype: int64
    
    
    689    2
    696    2
    724    1
    647    1
    650    1
    720    1
    667    1
    626    1
    573    1
    613    1
    703    1
    683    1
    640    1
    655    1
    697    1
    694    1
    656    1
    661    1
    729    1
    751    1
    748    1
    644    1
    713    1
    764    1
    891    1
    622    1
    669    1
    737    1
    Name: R, dtype: int64
    
    
    5485    2
    5575    1
    5631    1
    5457    1
    5649    1
    5565    1
    5385    1
    5529    1
    5420    1
    5463    1
    5428    1
    5527    1
    5571    1
    5480    1
    5491    1
    5484    1
    5467    1
    5600    1
    5544    1
    5417    1
    5459    1
    5511    1
    5640    1
    5567    1
    5509    1
    5605    1
    5533    1
    5439    1
    5572    1
    Name: AB, dtype: int64
    
    
    1363    2
    1497    1
    1386    1
    1324    1
    1494    1
    1486    1
    1346    1
    1374    1
    1361    1
    1420    1
    1351    1
    1382    1
    1378    1
    1341    1
    1462    1
    1405    1
    1349    1
    1379    1
    1331    1
    1419    1
    1495    1
    1383    1
    1370    1
    1397    1
    1480    1
    1515    1
    1381    1
    1395    1
    1479    1
    Name: H, dtype: int64
    
    
    272    3
    260    2
    289    2
    278    2
    277    2
    274    2
    288    2
    300    1
    292    1
    251    1
    236    1
    265    1
    295    1
    257    1
    243    1
    262    1
    279    1
    294    1
    246    1
    308    1
    303    1
    263    1
    Name: 2B, dtype: int64
    
    
    27    3
    39    2
    49    2
    17    2
    32    2
    26    2
    42    1
    48    1
    37    1
    18    1
    40    1
    13    1
    34    1
    30    1
    21    1
    46    1
    22    1
    44    1
    33    1
    20    1
    19    1
    29    1
    36    1
    Name: 3B, dtype: int64
    
    
    136    2
    167    2
    177    2
    139    1
    137    1
    148    1
    154    1
    187    1
    130    1
    100    1
    120    1
    145    1
    171    1
    140    1
    198    1
    146    1
    156    1
    176    1
    230    1
    172    1
    161    1
    217    1
    212    1
    232    1
    151    1
    141    1
    186    1
    Name: HR, dtype: int64
    
    
    478    2
    383    1
    461    1
    426    1
    490    1
    457    1
    563    1
    387    1
    471    1
    375    1
    539    1
    488    1
    496    1
    412    1
    567    1
    506    1
    439    1
    475    1
    435    1
    486    1
    503    1
    436    1
    418    1
    554    1
    570    1
    455    1
    404    1
    533    1
    388    1
    Name: BB, dtype: int64
    
    
    1150    2
    973     1
    1267    1
    1327    1
    1312    1
    1159    1
    1258    1
    1274    1
    1107    1
    1344    1
    1290    1
    1255    1
    1299    1
    1518    1
    1322    1
    1119    1
    1264    1
    1336    1
    1392    1
    1233    1
    1148    1
    1310    1
    1331    1
    1227    1
    1151    1
    1259    1
    1231    1
    1157    1
    1283    1
    Name: SO, dtype: int64
    
    
    69     3
    88     2
    78     1
    82     1
    132    1
    93     1
    59     1
    112    1
    57     1
    51     1
    134    1
    84     1
    95     1
    98     1
    104    1
    70     1
    52     1
    121    1
    101    1
    71     1
    87     1
    44     1
    63     1
    83     1
    68     1
    86     1
    97     1
    Name: SB, dtype: int64
    
    
    641    1
    700    1
    731    1
    713    1
    627    1
    595    1
    809    1
    760    1
    678    1
    635    1
    613    1
    754    1
    737    1
    608    1
    596    1
    525    1
    729    1
    726    1
    675    1
    618    1
    733    1
    753    1
    642    1
    693    1
    698    1
    670    1
    803    1
    701    1
    640    1
    844    1
    Name: RA, dtype: int64
    
    
    601    1
    653    1
    655    1
    659    1
    597    1
    553    1
    749    1
    698    1
    638    1
    577    1
    557    1
    700    1
    682    1
    546    1
    532    1
    478    1
    664    1
    677    1
    630    1
    572    1
    680    1
    694    1
    604    1
    646    1
    652    1
    609    1
    746    1
    643    1
    584    1
    799    1
    Name: ER, dtype: int64
    
    
    3.73    1
    4.07    1
    4.09    1
    4.04    1
    3.72    1
    3.44    1
    4.69    1
    4.41    1
    4.02    1
    3.62    1
    3.43    1
    4.33    1
    4.28    1
    3.36    1
    3.21    1
    2.94    1
    4.14    1
    4.16    1
    3.94    1
    3.57    1
    4.24    1
    4.31    1
    3.74    1
    4.05    1
    4.03    1
    3.80    1
    4.64    1
    3.98    1
    3.67    1
    5.04    1
    Name: ERA, dtype: int64
    
    
    1     7
    2     4
    7     4
    3     3
    0     3
    5     3
    6     3
    4     2
    11    1
    Name: CG, dtype: int64
    
    
    12    7
    10    5
    13    3
    8     2
    9     2
    4     2
    15    2
    21    2
    7     2
    14    1
    18    1
    6     1
    Name: SHO, dtype: int64
    
    
    35    4
    41    3
    45    3
    44    2
    48    2
    40    2
    56    1
    28    1
    47    1
    50    1
    54    1
    62    1
    39    1
    46    1
    60    1
    43    1
    34    1
    37    1
    38    1
    36    1
    Name: SV, dtype: int64
    
    
    88     3
    90     3
    86     3
    93     2
    77     2
    95     2
    122    1
    78     1
    75     1
    117    1
    116    1
    111    1
    94     1
    96     1
    126    1
    85     1
    119    1
    97     1
    101    1
    79     1
    92     1
    Name: E, dtype: int64
    
    
    


```python
df.shape[0]
```




    30




```python
df.isnull().sum()
```




    W      0
    R      0
    AB     0
    H      0
    2B     0
    3B     0
    HR     0
    BB     0
    SO     0
    SB     0
    RA     0
    ER     0
    ERA    0
    CG     0
    SHO    0
    SV     0
    E      0
    dtype: int64




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>W</th>
      <th>R</th>
      <th>AB</th>
      <th>H</th>
      <th>2B</th>
      <th>3B</th>
      <th>HR</th>
      <th>BB</th>
      <th>SO</th>
      <th>SB</th>
      <th>RA</th>
      <th>ER</th>
      <th>ERA</th>
      <th>CG</th>
      <th>SHO</th>
      <th>SV</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.00000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>80.966667</td>
      <td>688.233333</td>
      <td>5516.266667</td>
      <td>1403.533333</td>
      <td>274.733333</td>
      <td>31.300000</td>
      <td>163.633333</td>
      <td>469.100000</td>
      <td>1248.20000</td>
      <td>83.500000</td>
      <td>688.233333</td>
      <td>635.833333</td>
      <td>3.956333</td>
      <td>3.466667</td>
      <td>11.300000</td>
      <td>43.066667</td>
      <td>94.333333</td>
    </tr>
    <tr>
      <th>std</th>
      <td>10.453455</td>
      <td>58.761754</td>
      <td>70.467372</td>
      <td>57.140923</td>
      <td>18.095405</td>
      <td>10.452355</td>
      <td>31.823309</td>
      <td>57.053725</td>
      <td>103.75947</td>
      <td>22.815225</td>
      <td>72.108005</td>
      <td>70.140786</td>
      <td>0.454089</td>
      <td>2.763473</td>
      <td>4.120177</td>
      <td>7.869335</td>
      <td>13.958889</td>
    </tr>
    <tr>
      <th>min</th>
      <td>63.000000</td>
      <td>573.000000</td>
      <td>5385.000000</td>
      <td>1324.000000</td>
      <td>236.000000</td>
      <td>13.000000</td>
      <td>100.000000</td>
      <td>375.000000</td>
      <td>973.00000</td>
      <td>44.000000</td>
      <td>525.000000</td>
      <td>478.000000</td>
      <td>2.940000</td>
      <td>0.000000</td>
      <td>4.000000</td>
      <td>28.000000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>74.000000</td>
      <td>651.250000</td>
      <td>5464.000000</td>
      <td>1363.000000</td>
      <td>262.250000</td>
      <td>23.000000</td>
      <td>140.250000</td>
      <td>428.250000</td>
      <td>1157.50000</td>
      <td>69.000000</td>
      <td>636.250000</td>
      <td>587.250000</td>
      <td>3.682500</td>
      <td>1.000000</td>
      <td>9.000000</td>
      <td>37.250000</td>
      <td>86.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>81.000000</td>
      <td>689.000000</td>
      <td>5510.000000</td>
      <td>1382.500000</td>
      <td>275.500000</td>
      <td>31.000000</td>
      <td>158.500000</td>
      <td>473.000000</td>
      <td>1261.50000</td>
      <td>83.500000</td>
      <td>695.500000</td>
      <td>644.500000</td>
      <td>4.025000</td>
      <td>3.000000</td>
      <td>12.000000</td>
      <td>42.000000</td>
      <td>91.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>87.750000</td>
      <td>718.250000</td>
      <td>5570.000000</td>
      <td>1451.500000</td>
      <td>288.750000</td>
      <td>39.000000</td>
      <td>177.000000</td>
      <td>501.250000</td>
      <td>1311.50000</td>
      <td>96.500000</td>
      <td>732.500000</td>
      <td>679.250000</td>
      <td>4.220000</td>
      <td>5.750000</td>
      <td>13.000000</td>
      <td>46.750000</td>
      <td>96.750000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>100.000000</td>
      <td>891.000000</td>
      <td>5649.000000</td>
      <td>1515.000000</td>
      <td>308.000000</td>
      <td>49.000000</td>
      <td>232.000000</td>
      <td>570.000000</td>
      <td>1518.00000</td>
      <td>134.000000</td>
      <td>844.000000</td>
      <td>799.000000</td>
      <td>5.040000</td>
      <td>11.000000</td>
      <td>21.000000</td>
      <td>62.000000</td>
      <td>126.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
ax = sns.countplot(x='2B',data=df)
print(df['2B'].value_counts())
```

    272    3
    260    2
    289    2
    278    2
    277    2
    274    2
    288    2
    300    1
    292    1
    251    1
    236    1
    265    1
    295    1
    257    1
    243    1
    262    1
    279    1
    294    1
    246    1
    308    1
    303    1
    263    1
    Name: 2B, dtype: int64
    


    
![png](output_23_1.png)
    



```python
print(df['W'].value_counts())
```

    68     3
    81     2
    76     2
    74     2
    83     2
    98     1
    84     1
    92     1
    63     1
    67     1
    71     1
    90     1
    64     1
    97     1
    95     1
    100    1
    85     1
    86     1
    88     1
    78     1
    80     1
    87     1
    93     1
    79     1
    Name: W, dtype: int64
    


```python
print(df['H'].value_counts())
ax= sns.countplot(x='H',data=df)
plt.show()
```

    1363    2
    1497    1
    1386    1
    1324    1
    1494    1
    1486    1
    1346    1
    1374    1
    1361    1
    1420    1
    1351    1
    1382    1
    1378    1
    1341    1
    1462    1
    1405    1
    1349    1
    1379    1
    1331    1
    1419    1
    1495    1
    1383    1
    1370    1
    1397    1
    1480    1
    1515    1
    1381    1
    1395    1
    1479    1
    Name: H, dtype: int64
    


    
![png](output_25_1.png)
    



```python
print(df['3B'].value_counts())
ax= sns.countplot(x='3B',data=df)
plt.show()
```

    27    3
    39    2
    49    2
    17    2
    32    2
    26    2
    42    1
    48    1
    37    1
    18    1
    40    1
    13    1
    34    1
    30    1
    21    1
    46    1
    22    1
    44    1
    33    1
    20    1
    19    1
    29    1
    36    1
    Name: 3B, dtype: int64
    


    
![png](output_26_1.png)
    



```python
print(df['AB'].value_counts())
ax= sns.countplot(x='AB',data=df)
plt.show()
```

    5485    2
    5575    1
    5631    1
    5457    1
    5649    1
    5565    1
    5385    1
    5529    1
    5420    1
    5463    1
    5428    1
    5527    1
    5571    1
    5480    1
    5491    1
    5484    1
    5467    1
    5600    1
    5544    1
    5417    1
    5459    1
    5511    1
    5640    1
    5567    1
    5509    1
    5605    1
    5533    1
    5439    1
    5572    1
    Name: AB, dtype: int64
    


    
![png](output_27_1.png)
    



```python
print(df['HR'].value_counts())
ax= sns.countplot(x='HR',data=df)
plt.show()
```

    136    2
    167    2
    177    2
    139    1
    137    1
    148    1
    154    1
    187    1
    130    1
    100    1
    120    1
    145    1
    171    1
    140    1
    198    1
    146    1
    156    1
    176    1
    230    1
    172    1
    161    1
    217    1
    212    1
    232    1
    151    1
    141    1
    186    1
    Name: HR, dtype: int64
    


    
![png](output_28_1.png)
    



```python
print(df['R'].value_counts())
ax= sns.countplot(x='R',data=df)
plt.show()
```

    689    2
    696    2
    724    1
    647    1
    650    1
    720    1
    667    1
    626    1
    573    1
    613    1
    703    1
    683    1
    640    1
    655    1
    697    1
    694    1
    656    1
    661    1
    729    1
    751    1
    748    1
    644    1
    713    1
    764    1
    891    1
    622    1
    669    1
    737    1
    Name: R, dtype: int64
    


    
![png](output_29_1.png)
    



```python
os.getcwd()
```




    'C:\\Users\\Laksh\\Downloads'




```python
os.chdir("C:\\Users\\Laksh\\Downloads")
```


```python
df = pd.read_csv("C:\\Users\\Laksh\\avocado.csv (1).zip")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Date</th>
      <th>AveragePrice</th>
      <th>Total Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total Bags</th>
      <th>Small Bags</th>
      <th>Large Bags</th>
      <th>XLarge Bags</th>
      <th>type</th>
      <th>year</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2015-12-27</td>
      <td>1.33</td>
      <td>64236.62</td>
      <td>1036.74</td>
      <td>54454.85</td>
      <td>48.16</td>
      <td>8696.87</td>
      <td>8603.62</td>
      <td>93.25</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2015-12-20</td>
      <td>1.35</td>
      <td>54876.98</td>
      <td>674.28</td>
      <td>44638.81</td>
      <td>58.33</td>
      <td>9505.56</td>
      <td>9408.07</td>
      <td>97.49</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2015-12-13</td>
      <td>0.93</td>
      <td>118220.22</td>
      <td>794.70</td>
      <td>109149.67</td>
      <td>130.50</td>
      <td>8145.35</td>
      <td>8042.21</td>
      <td>103.14</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2015-12-06</td>
      <td>1.08</td>
      <td>78992.15</td>
      <td>1132.00</td>
      <td>71976.41</td>
      <td>72.58</td>
      <td>5811.16</td>
      <td>5677.40</td>
      <td>133.76</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2015-11-29</td>
      <td>1.28</td>
      <td>51039.60</td>
      <td>941.48</td>
      <td>43838.39</td>
      <td>75.78</td>
      <td>6183.95</td>
      <td>5986.26</td>
      <td>197.69</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18244</th>
      <td>7</td>
      <td>2018-02-04</td>
      <td>1.63</td>
      <td>17074.83</td>
      <td>2046.96</td>
      <td>1529.20</td>
      <td>0.00</td>
      <td>13498.67</td>
      <td>13066.82</td>
      <td>431.85</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18245</th>
      <td>8</td>
      <td>2018-01-28</td>
      <td>1.71</td>
      <td>13888.04</td>
      <td>1191.70</td>
      <td>3431.50</td>
      <td>0.00</td>
      <td>9264.84</td>
      <td>8940.04</td>
      <td>324.80</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18246</th>
      <td>9</td>
      <td>2018-01-21</td>
      <td>1.87</td>
      <td>13766.76</td>
      <td>1191.92</td>
      <td>2452.79</td>
      <td>727.94</td>
      <td>9394.11</td>
      <td>9351.80</td>
      <td>42.31</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18247</th>
      <td>10</td>
      <td>2018-01-14</td>
      <td>1.93</td>
      <td>16205.22</td>
      <td>1527.63</td>
      <td>2981.04</td>
      <td>727.01</td>
      <td>10969.54</td>
      <td>10919.54</td>
      <td>50.00</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18248</th>
      <td>11</td>
      <td>2018-01-07</td>
      <td>1.62</td>
      <td>17489.58</td>
      <td>2894.77</td>
      <td>2356.13</td>
      <td>224.53</td>
      <td>12014.15</td>
      <td>11988.14</td>
      <td>26.01</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
  </tbody>
</table>
<p>18249 rows × 14 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Date</th>
      <th>AveragePrice</th>
      <th>Total Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total Bags</th>
      <th>Small Bags</th>
      <th>Large Bags</th>
      <th>XLarge Bags</th>
      <th>type</th>
      <th>year</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2015-12-27</td>
      <td>1.33</td>
      <td>64236.62</td>
      <td>1036.74</td>
      <td>54454.85</td>
      <td>48.16</td>
      <td>8696.87</td>
      <td>8603.62</td>
      <td>93.25</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2015-12-20</td>
      <td>1.35</td>
      <td>54876.98</td>
      <td>674.28</td>
      <td>44638.81</td>
      <td>58.33</td>
      <td>9505.56</td>
      <td>9408.07</td>
      <td>97.49</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2015-12-13</td>
      <td>0.93</td>
      <td>118220.22</td>
      <td>794.70</td>
      <td>109149.67</td>
      <td>130.50</td>
      <td>8145.35</td>
      <td>8042.21</td>
      <td>103.14</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2015-12-06</td>
      <td>1.08</td>
      <td>78992.15</td>
      <td>1132.00</td>
      <td>71976.41</td>
      <td>72.58</td>
      <td>5811.16</td>
      <td>5677.40</td>
      <td>133.76</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2015-11-29</td>
      <td>1.28</td>
      <td>51039.60</td>
      <td>941.48</td>
      <td>43838.39</td>
      <td>75.78</td>
      <td>6183.95</td>
      <td>5986.26</td>
      <td>197.69</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Date</th>
      <th>AveragePrice</th>
      <th>Total Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total Bags</th>
      <th>Small Bags</th>
      <th>Large Bags</th>
      <th>XLarge Bags</th>
      <th>type</th>
      <th>year</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>18244</th>
      <td>7</td>
      <td>2018-02-04</td>
      <td>1.63</td>
      <td>17074.83</td>
      <td>2046.96</td>
      <td>1529.20</td>
      <td>0.00</td>
      <td>13498.67</td>
      <td>13066.82</td>
      <td>431.85</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18245</th>
      <td>8</td>
      <td>2018-01-28</td>
      <td>1.71</td>
      <td>13888.04</td>
      <td>1191.70</td>
      <td>3431.50</td>
      <td>0.00</td>
      <td>9264.84</td>
      <td>8940.04</td>
      <td>324.80</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18246</th>
      <td>9</td>
      <td>2018-01-21</td>
      <td>1.87</td>
      <td>13766.76</td>
      <td>1191.92</td>
      <td>2452.79</td>
      <td>727.94</td>
      <td>9394.11</td>
      <td>9351.80</td>
      <td>42.31</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18247</th>
      <td>10</td>
      <td>2018-01-14</td>
      <td>1.93</td>
      <td>16205.22</td>
      <td>1527.63</td>
      <td>2981.04</td>
      <td>727.01</td>
      <td>10969.54</td>
      <td>10919.54</td>
      <td>50.00</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18248</th>
      <td>11</td>
      <td>2018-01-07</td>
      <td>1.62</td>
      <td>17489.58</td>
      <td>2894.77</td>
      <td>2356.13</td>
      <td>224.53</td>
      <td>12014.15</td>
      <td>11988.14</td>
      <td>26.01</td>
      <td>0.0</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (18249, 14)




```python
df.columns
```




    Index(['Unnamed: 0', 'Date', 'AveragePrice', 'Total Volume', '4046', '4225',
           '4770', 'Total Bags', 'Small Bags', 'Large Bags', 'XLarge Bags', 'type',
           'year', 'region'],
          dtype='object')




```python
df.columns.tolist()
```




    ['Unnamed: 0',
     'Date',
     'AveragePrice',
     'Total Volume',
     '4046',
     '4225',
     '4770',
     'Total Bags',
     'Small Bags',
     'Large Bags',
     'XLarge Bags',
     'type',
     'year',
     'region']




```python
df.dtypes
```




    Unnamed: 0        int64
    Date             object
    AveragePrice    float64
    Total Volume    float64
    4046            float64
    4225            float64
    4770            float64
    Total Bags      float64
    Small Bags      float64
    Large Bags      float64
    XLarge Bags     float64
    type             object
    year              int64
    region           object
    dtype: object




```python
df.isnull().sum()
```




    Unnamed: 0      0
    Date            0
    AveragePrice    0
    Total Volume    0
    4046            0
    4225            0
    4770            0
    Total Bags      0
    Small Bags      0
    Large Bags      0
    XLarge Bags     0
    type            0
    year            0
    region          0
    dtype: int64




```python
df.isnull().sum().sum()
```




    0




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 18249 entries, 0 to 18248
    Data columns (total 14 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   Unnamed: 0    18249 non-null  int64  
     1   Date          18249 non-null  object 
     2   AveragePrice  18249 non-null  float64
     3   Total Volume  18249 non-null  float64
     4   4046          18249 non-null  float64
     5   4225          18249 non-null  float64
     6   4770          18249 non-null  float64
     7   Total Bags    18249 non-null  float64
     8   Small Bags    18249 non-null  float64
     9   Large Bags    18249 non-null  float64
     10  XLarge Bags   18249 non-null  float64
     11  type          18249 non-null  object 
     12  year          18249 non-null  int64  
     13  region        18249 non-null  object 
    dtypes: float64(9), int64(2), object(3)
    memory usage: 1.9+ MB
    


```python
for i in df.columns:
    print(df[i].value_counts())
    print('\n')
```

    0     432
    7     432
    1     432
    11    432
    9     432
    8     432
    10    432
    6     432
    5     432
    4     432
    3     432
    2     432
    41    324
    34    324
    35    324
    36    324
    37    324
    38    324
    39    324
    40    324
    47    324
    42    324
    43    324
    44    324
    45    324
    46    324
    32    324
    48    324
    49    324
    50    324
    33    324
    26    324
    31    324
    30    324
    12    324
    13    324
    14    324
    15    324
    16    324
    17    324
    18    324
    19    324
    20    324
    21    324
    22    324
    23    324
    24    324
    25    324
    27    324
    28    324
    29    324
    51    322
    52    107
    Name: Unnamed: 0, dtype: int64
    
    
    2015-12-27    108
    2017-12-24    108
    2017-12-10    108
    2017-12-03    108
    2017-11-26    108
                 ... 
    2016-11-06    108
    2018-01-07    108
    2017-06-18    107
    2017-06-25    107
    2015-12-06    107
    Name: Date, Length: 169, dtype: int64
    
    
    1.15    202
    1.18    199
    1.08    194
    1.26    193
    1.13    192
           ... 
    3.25      1
    3.12      1
    2.68      1
    3.03      1
    3.17      1
    Name: AveragePrice, Length: 259, dtype: int64
    
    
    4103.97       2
    3529.44       2
    46602.16      2
    13234.04      2
    3713.49       2
                 ..
    874349.55     1
    1621253.97    1
    830499.38     1
    845065.66     1
    17489.58      1
    Name: Total Volume, Length: 18237, dtype: int64
    
    
    0.00       242
    3.00        10
    4.00         8
    1.24         8
    1.00         8
              ... 
    1486.31      1
    1761.80      1
    1772.26      1
    1803.39      1
    2894.77      1
    Name: 4046, Length: 17702, dtype: int64
    
    
    0.00         61
    177.87        3
    215.36        3
    1.30          3
    1.26          3
                 ..
    417905.67     1
    275986.91     1
    277789.30     1
    378155.00     1
    2356.13       1
    Name: 4225, Length: 18103, dtype: int64
    
    
    0.00      5497
    2.66         7
    3.32         7
    10.97        6
    1.59         6
              ... 
    547.08       1
    155.87       1
    72.01        1
    128.06       1
    224.53       1
    Name: 4770, Length: 12071, dtype: int64
    
    
    0.00         15
    990.00        5
    300.00        5
    550.00        4
    266.67        4
                 ..
    90196.05      1
    130858.02     1
    510679.10     1
    84522.00      1
    12014.15      1
    Name: Total Bags, Length: 18097, dtype: int64
    
    
    0.00        159
    203.33       11
    223.33       10
    533.33       10
    123.33        8
               ... 
    14002.00      1
    32441.00      1
    29560.96      1
    22077.20      1
    11988.14      1
    Name: Small Bags, Length: 17321, dtype: int64
    
    
    0.00          2370
    3.33           187
    6.67            78
    10.00           47
    4.44            38
                  ... 
    2528089.14       1
    2287449.76       1
    731388.25        1
    673464.14        1
    26.01            1
    Name: Large Bags, Length: 15082, dtype: int64
    
    
    0.00       12048
    3.33          29
    6.67          16
    1.11          15
    5.00          12
               ...  
    3018.05        1
    2739.44        1
    9301.67        1
    8640.00        1
    24.18          1
    Name: XLarge Bags, Length: 5588, dtype: int64
    
    
    conventional    9126
    organic         9123
    Name: type, dtype: int64
    
    
    2017    5722
    2016    5616
    2015    5615
    2018    1296
    Name: year, dtype: int64
    
    
    Albany                 338
    Sacramento             338
    Northeast              338
    NorthernNewEngland     338
    Orlando                338
    Philadelphia           338
    PhoenixTucson          338
    Pittsburgh             338
    Plains                 338
    Portland               338
    RaleighGreensboro      338
    RichmondNorfolk        338
    Roanoke                338
    SanDiego               338
    Atlanta                338
    SanFrancisco           338
    Seattle                338
    SouthCarolina          338
    SouthCentral           338
    Southeast              338
    Spokane                338
    StLouis                338
    Syracuse               338
    Tampa                  338
    TotalUS                338
    West                   338
    NewYork                338
    NewOrleansMobile       338
    Nashville              338
    Midsouth               338
    BaltimoreWashington    338
    Boise                  338
    Boston                 338
    BuffaloRochester       338
    California             338
    Charlotte              338
    Chicago                338
    CincinnatiDayton       338
    Columbus               338
    DallasFtWorth          338
    Denver                 338
    Detroit                338
    GrandRapids            338
    GreatLakes             338
    HarrisburgScranton     338
    HartfordSpringfield    338
    Houston                338
    Indianapolis           338
    Jacksonville           338
    LasVegas               338
    LosAngeles             338
    Louisville             338
    MiamiFtLauderdale      338
    WestTexNewMexico       335
    Name: region, dtype: int64
    
    
    


```python
df.shape[0]
```




    18249




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>AveragePrice</th>
      <th>Total Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total Bags</th>
      <th>Small Bags</th>
      <th>Large Bags</th>
      <th>XLarge Bags</th>
      <th>year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>18249.000000</td>
      <td>18249.000000</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>18249.000000</td>
      <td>18249.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>24.232232</td>
      <td>1.405978</td>
      <td>8.506440e+05</td>
      <td>2.930084e+05</td>
      <td>2.951546e+05</td>
      <td>2.283974e+04</td>
      <td>2.396392e+05</td>
      <td>1.821947e+05</td>
      <td>5.433809e+04</td>
      <td>3106.426507</td>
      <td>2016.147899</td>
    </tr>
    <tr>
      <th>std</th>
      <td>15.481045</td>
      <td>0.402677</td>
      <td>3.453545e+06</td>
      <td>1.264989e+06</td>
      <td>1.204120e+06</td>
      <td>1.074641e+05</td>
      <td>9.862424e+05</td>
      <td>7.461785e+05</td>
      <td>2.439660e+05</td>
      <td>17692.894652</td>
      <td>0.939938</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.440000</td>
      <td>8.456000e+01</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>2015.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>10.000000</td>
      <td>1.100000</td>
      <td>1.083858e+04</td>
      <td>8.540700e+02</td>
      <td>3.008780e+03</td>
      <td>0.000000e+00</td>
      <td>5.088640e+03</td>
      <td>2.849420e+03</td>
      <td>1.274700e+02</td>
      <td>0.000000</td>
      <td>2015.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>24.000000</td>
      <td>1.370000</td>
      <td>1.073768e+05</td>
      <td>8.645300e+03</td>
      <td>2.906102e+04</td>
      <td>1.849900e+02</td>
      <td>3.974383e+04</td>
      <td>2.636282e+04</td>
      <td>2.647710e+03</td>
      <td>0.000000</td>
      <td>2016.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>38.000000</td>
      <td>1.660000</td>
      <td>4.329623e+05</td>
      <td>1.110202e+05</td>
      <td>1.502069e+05</td>
      <td>6.243420e+03</td>
      <td>1.107834e+05</td>
      <td>8.333767e+04</td>
      <td>2.202925e+04</td>
      <td>132.500000</td>
      <td>2017.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>52.000000</td>
      <td>3.250000</td>
      <td>6.250565e+07</td>
      <td>2.274362e+07</td>
      <td>2.047057e+07</td>
      <td>2.546439e+06</td>
      <td>1.937313e+07</td>
      <td>1.338459e+07</td>
      <td>5.719097e+06</td>
      <td>551693.650000</td>
      <td>2018.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.heatmap(df.isnull())
```




    <AxesSubplot:>




    
![png](output_45_1.png)
    



```python
print(df['AveragePrice'].value_counts())
ax= sns.countplot(x='AveragePrice',data=df)
plt.show()
```

    1.15    202
    1.18    199
    1.08    194
    1.26    193
    1.13    192
           ... 
    3.25      1
    3.12      1
    2.68      1
    3.03      1
    3.17      1
    Name: AveragePrice, Length: 259, dtype: int64
    


    
![png](output_46_1.png)
    



```python
print(df['Total Volume'].value_counts())
ax= sns.countplot(x='Total Volume',data=df)
plt.show()
```

    4103.97       2
    3529.44       2
    46602.16      2
    13234.04      2
    3713.49       2
                 ..
    874349.55     1
    1621253.97    1
    830499.38     1
    845065.66     1
    17489.58      1
    Name: Total Volume, Length: 18237, dtype: int64
    


    
![png](output_47_1.png)
    



```python

```


```python

```


```python

```


```python
os.getcwd()
```




    'C:\\Users\\Laksh\\Downloads'




```python
os.chdir("C:\\Users\\Laksh\\Downloads")
```


```python
df = pd.read_csv("C:\\Users\\Laksh\\ibm-hr-analytics-employee-attrition-performance.zip")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1465</th>
      <td>36</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>884</td>
      <td>Research &amp; Development</td>
      <td>23</td>
      <td>2</td>
      <td>Medical</td>
      <td>1</td>
      <td>2061</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>1</td>
      <td>17</td>
      <td>3</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1466</th>
      <td>39</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>613</td>
      <td>Research &amp; Development</td>
      <td>6</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>2062</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>1</td>
      <td>9</td>
      <td>5</td>
      <td>3</td>
      <td>7</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1467</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>155</td>
      <td>Research &amp; Development</td>
      <td>4</td>
      <td>3</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2064</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>0</td>
      <td>3</td>
      <td>6</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1468</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1023</td>
      <td>Sales</td>
      <td>2</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>2065</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>0</td>
      <td>17</td>
      <td>3</td>
      <td>2</td>
      <td>9</td>
      <td>6</td>
      <td>0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>34</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>628</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>2068</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>1470 rows × 35 columns</p>
</div>




```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>32</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1005</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>8</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>2</td>
      <td>2</td>
      <td>7</td>
      <td>7</td>
      <td>3</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>59</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1324</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>10</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>3</td>
      <td>12</td>
      <td>3</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>30</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1358</td>
      <td>Research &amp; Development</td>
      <td>24</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>11</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>38</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>216</td>
      <td>Research &amp; Development</td>
      <td>23</td>
      <td>3</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>12</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>10</td>
      <td>2</td>
      <td>3</td>
      <td>9</td>
      <td>7</td>
      <td>1</td>
      <td>8</td>
    </tr>
    <tr>
      <th>9</th>
      <td>36</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>1299</td>
      <td>Research &amp; Development</td>
      <td>27</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>13</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>2</td>
      <td>17</td>
      <td>3</td>
      <td>2</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 35 columns</p>
</div>




```python
 df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 35 columns</p>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1465</th>
      <td>36</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>884</td>
      <td>Research &amp; Development</td>
      <td>23</td>
      <td>2</td>
      <td>Medical</td>
      <td>1</td>
      <td>2061</td>
      <td>...</td>
      <td>3</td>
      <td>80</td>
      <td>1</td>
      <td>17</td>
      <td>3</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1466</th>
      <td>39</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>613</td>
      <td>Research &amp; Development</td>
      <td>6</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>2062</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>1</td>
      <td>9</td>
      <td>5</td>
      <td>3</td>
      <td>7</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1467</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>155</td>
      <td>Research &amp; Development</td>
      <td>4</td>
      <td>3</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2064</td>
      <td>...</td>
      <td>2</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>0</td>
      <td>3</td>
      <td>6</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1468</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1023</td>
      <td>Sales</td>
      <td>2</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>2065</td>
      <td>...</td>
      <td>4</td>
      <td>80</td>
      <td>0</td>
      <td>17</td>
      <td>3</td>
      <td>2</td>
      <td>9</td>
      <td>6</td>
      <td>0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>34</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>628</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>3</td>
      <td>Medical</td>
      <td>1</td>
      <td>2068</td>
      <td>...</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>6</td>
      <td>3</td>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 35 columns</p>
</div>




```python
 df.shape
```




    (1470, 35)




```python
df.columns
```




    Index(['Age', 'Attrition', 'BusinessTravel', 'DailyRate', 'Department',
           'DistanceFromHome', 'Education', 'EducationField', 'EmployeeCount',
           'EmployeeNumber', 'EnvironmentSatisfaction', 'Gender', 'HourlyRate',
           'JobInvolvement', 'JobLevel', 'JobRole', 'JobSatisfaction',
           'MaritalStatus', 'MonthlyIncome', 'MonthlyRate', 'NumCompaniesWorked',
           'Over18', 'OverTime', 'PercentSalaryHike', 'PerformanceRating',
           'RelationshipSatisfaction', 'StandardHours', 'StockOptionLevel',
           'TotalWorkingYears', 'TrainingTimesLastYear', 'WorkLifeBalance',
           'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion',
           'YearsWithCurrManager'],
          dtype='object')




```python
df.columns.tolist()
```




    ['Age',
     'Attrition',
     'BusinessTravel',
     'DailyRate',
     'Department',
     'DistanceFromHome',
     'Education',
     'EducationField',
     'EmployeeCount',
     'EmployeeNumber',
     'EnvironmentSatisfaction',
     'Gender',
     'HourlyRate',
     'JobInvolvement',
     'JobLevel',
     'JobRole',
     'JobSatisfaction',
     'MaritalStatus',
     'MonthlyIncome',
     'MonthlyRate',
     'NumCompaniesWorked',
     'Over18',
     'OverTime',
     'PercentSalaryHike',
     'PerformanceRating',
     'RelationshipSatisfaction',
     'StandardHours',
     'StockOptionLevel',
     'TotalWorkingYears',
     'TrainingTimesLastYear',
     'WorkLifeBalance',
     'YearsAtCompany',
     'YearsInCurrentRole',
     'YearsSinceLastPromotion',
     'YearsWithCurrManager']




```python
df.dtypes
```




    Age                          int64
    Attrition                   object
    BusinessTravel              object
    DailyRate                    int64
    Department                  object
    DistanceFromHome             int64
    Education                    int64
    EducationField              object
    EmployeeCount                int64
    EmployeeNumber               int64
    EnvironmentSatisfaction      int64
    Gender                      object
    HourlyRate                   int64
    JobInvolvement               int64
    JobLevel                     int64
    JobRole                     object
    JobSatisfaction              int64
    MaritalStatus               object
    MonthlyIncome                int64
    MonthlyRate                  int64
    NumCompaniesWorked           int64
    Over18                      object
    OverTime                    object
    PercentSalaryHike            int64
    PerformanceRating            int64
    RelationshipSatisfaction     int64
    StandardHours                int64
    StockOptionLevel             int64
    TotalWorkingYears            int64
    TrainingTimesLastYear        int64
    WorkLifeBalance              int64
    YearsAtCompany               int64
    YearsInCurrentRole           int64
    YearsSinceLastPromotion      int64
    YearsWithCurrManager         int64
    dtype: object




```python
df.isnull().sum()
```




    Age                         0
    Attrition                   0
    BusinessTravel              0
    DailyRate                   0
    Department                  0
    DistanceFromHome            0
    Education                   0
    EducationField              0
    EmployeeCount               0
    EmployeeNumber              0
    EnvironmentSatisfaction     0
    Gender                      0
    HourlyRate                  0
    JobInvolvement              0
    JobLevel                    0
    JobRole                     0
    JobSatisfaction             0
    MaritalStatus               0
    MonthlyIncome               0
    MonthlyRate                 0
    NumCompaniesWorked          0
    Over18                      0
    OverTime                    0
    PercentSalaryHike           0
    PerformanceRating           0
    RelationshipSatisfaction    0
    StandardHours               0
    StockOptionLevel            0
    TotalWorkingYears           0
    TrainingTimesLastYear       0
    WorkLifeBalance             0
    YearsAtCompany              0
    YearsInCurrentRole          0
    YearsSinceLastPromotion     0
    YearsWithCurrManager        0
    dtype: int64




```python
df.isnull().sum().sum()
```




    0




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1470 entries, 0 to 1469
    Data columns (total 35 columns):
     #   Column                    Non-Null Count  Dtype 
    ---  ------                    --------------  ----- 
     0   Age                       1470 non-null   int64 
     1   Attrition                 1470 non-null   object
     2   BusinessTravel            1470 non-null   object
     3   DailyRate                 1470 non-null   int64 
     4   Department                1470 non-null   object
     5   DistanceFromHome          1470 non-null   int64 
     6   Education                 1470 non-null   int64 
     7   EducationField            1470 non-null   object
     8   EmployeeCount             1470 non-null   int64 
     9   EmployeeNumber            1470 non-null   int64 
     10  EnvironmentSatisfaction   1470 non-null   int64 
     11  Gender                    1470 non-null   object
     12  HourlyRate                1470 non-null   int64 
     13  JobInvolvement            1470 non-null   int64 
     14  JobLevel                  1470 non-null   int64 
     15  JobRole                   1470 non-null   object
     16  JobSatisfaction           1470 non-null   int64 
     17  MaritalStatus             1470 non-null   object
     18  MonthlyIncome             1470 non-null   int64 
     19  MonthlyRate               1470 non-null   int64 
     20  NumCompaniesWorked        1470 non-null   int64 
     21  Over18                    1470 non-null   object
     22  OverTime                  1470 non-null   object
     23  PercentSalaryHike         1470 non-null   int64 
     24  PerformanceRating         1470 non-null   int64 
     25  RelationshipSatisfaction  1470 non-null   int64 
     26  StandardHours             1470 non-null   int64 
     27  StockOptionLevel          1470 non-null   int64 
     28  TotalWorkingYears         1470 non-null   int64 
     29  TrainingTimesLastYear     1470 non-null   int64 
     30  WorkLifeBalance           1470 non-null   int64 
     31  YearsAtCompany            1470 non-null   int64 
     32  YearsInCurrentRole        1470 non-null   int64 
     33  YearsSinceLastPromotion   1470 non-null   int64 
     34  YearsWithCurrManager      1470 non-null   int64 
    dtypes: int64(26), object(9)
    memory usage: 402.1+ KB
    


```python
for i in df.columns:
    print(df[i].value_counts())
    print('\n')
```

    35    78
    34    77
    36    69
    31    69
    29    68
    32    61
    30    60
    33    58
    38    58
    40    57
    37    50
    27    48
    28    48
    42    46
    39    42
    45    41
    41    40
    26    39
    44    33
    46    33
    43    32
    50    30
    25    26
    24    26
    49    24
    47    24
    55    22
    51    19
    53    19
    48    19
    54    18
    52    18
    22    16
    56    14
    23    14
    58    14
    21    13
    20    11
    59    10
    19     9
    18     8
    60     5
    57     4
    Name: Age, dtype: int64
    
    
    No     1233
    Yes     237
    Name: Attrition, dtype: int64
    
    
    Travel_Rarely        1043
    Travel_Frequently     277
    Non-Travel            150
    Name: BusinessTravel, dtype: int64
    
    
    691     6
    408     5
    530     5
    1329    5
    1082    5
           ..
    650     1
    279     1
    316     1
    314     1
    628     1
    Name: DailyRate, Length: 886, dtype: int64
    
    
    Research & Development    961
    Sales                     446
    Human Resources            63
    Name: Department, dtype: int64
    
    
    2     211
    1     208
    10     86
    9      85
    3      84
    7      84
    8      80
    5      65
    4      64
    6      59
    16     32
    11     29
    24     28
    23     27
    29     27
    15     26
    18     26
    26     25
    25     25
    20     25
    28     23
    19     22
    14     21
    12     20
    17     20
    22     19
    13     19
    21     18
    27     12
    Name: DistanceFromHome, dtype: int64
    
    
    3    572
    4    398
    2    282
    1    170
    5     48
    Name: Education, dtype: int64
    
    
    Life Sciences       606
    Medical             464
    Marketing           159
    Technical Degree    132
    Other                82
    Human Resources      27
    Name: EducationField, dtype: int64
    
    
    1    1470
    Name: EmployeeCount, dtype: int64
    
    
    1       1
    1391    1
    1389    1
    1387    1
    1383    1
           ..
    659     1
    657     1
    656     1
    655     1
    2068    1
    Name: EmployeeNumber, Length: 1470, dtype: int64
    
    
    3    453
    4    446
    2    287
    1    284
    Name: EnvironmentSatisfaction, dtype: int64
    
    
    Male      882
    Female    588
    Name: Gender, dtype: int64
    
    
    66    29
    98    28
    42    28
    48    28
    84    28
          ..
    31    15
    53    14
    68    14
    38    13
    34    12
    Name: HourlyRate, Length: 71, dtype: int64
    
    
    3    868
    2    375
    4    144
    1     83
    Name: JobInvolvement, dtype: int64
    
    
    1    543
    2    534
    3    218
    4    106
    5     69
    Name: JobLevel, dtype: int64
    
    
    Sales Executive              326
    Research Scientist           292
    Laboratory Technician        259
    Manufacturing Director       145
    Healthcare Representative    131
    Manager                      102
    Sales Representative          83
    Research Director             80
    Human Resources               52
    Name: JobRole, dtype: int64
    
    
    4    459
    3    442
    1    289
    2    280
    Name: JobSatisfaction, dtype: int64
    
    
    Married     673
    Single      470
    Divorced    327
    Name: MaritalStatus, dtype: int64
    
    
    2342     4
    6142     3
    2741     3
    2559     3
    2610     3
            ..
    7104     1
    2773     1
    19513    1
    3447     1
    4404     1
    Name: MonthlyIncome, Length: 1349, dtype: int64
    
    
    4223     3
    9150     3
    9558     2
    12858    2
    22074    2
            ..
    14561    1
    2671     1
    5718     1
    11757    1
    10228    1
    Name: MonthlyRate, Length: 1427, dtype: int64
    
    
    1    521
    0    197
    3    159
    2    146
    4    139
    7     74
    6     70
    5     63
    9     52
    8     49
    Name: NumCompaniesWorked, dtype: int64
    
    
    Y    1470
    Name: Over18, dtype: int64
    
    
    No     1054
    Yes     416
    Name: OverTime, dtype: int64
    
    
    11    210
    13    209
    14    201
    12    198
    15    101
    18     89
    17     82
    16     78
    19     76
    22     56
    20     55
    21     48
    23     28
    24     21
    25     18
    Name: PercentSalaryHike, dtype: int64
    
    
    3    1244
    4     226
    Name: PerformanceRating, dtype: int64
    
    
    3    459
    4    432
    2    303
    1    276
    Name: RelationshipSatisfaction, dtype: int64
    
    
    80    1470
    Name: StandardHours, dtype: int64
    
    
    0    631
    1    596
    2    158
    3     85
    Name: StockOptionLevel, dtype: int64
    
    
    10    202
    6     125
    8     103
    9      96
    5      88
    7      81
    1      81
    4      63
    12     48
    3      42
    15     40
    16     37
    11     36
    13     36
    21     34
    17     33
    2      31
    14     31
    20     30
    18     27
    19     22
    23     22
    22     21
    24     18
    25     14
    28     14
    26     14
    0      11
    29     10
    31      9
    32      9
    30      7
    33      7
    27      7
    36      6
    34      5
    37      4
    35      3
    40      2
    38      1
    Name: TotalWorkingYears, dtype: int64
    
    
    2    547
    3    491
    4    123
    5    119
    1     71
    6     65
    0     54
    Name: TrainingTimesLastYear, dtype: int64
    
    
    3    893
    2    344
    4    153
    1     80
    Name: WorkLifeBalance, dtype: int64
    
    
    5     196
    1     171
    3     128
    2     127
    10    120
    4     110
    7      90
    9      82
    8      80
    6      76
    0      44
    11     32
    20     27
    13     24
    15     20
    14     18
    22     15
    12     14
    21     14
    18     13
    16     12
    19     11
    17      9
    24      6
    33      5
    25      4
    26      4
    31      3
    32      3
    27      2
    36      2
    29      2
    23      2
    37      1
    40      1
    34      1
    30      1
    Name: YearsAtCompany, dtype: int64
    
    
    2     372
    0     244
    7     222
    3     135
    4     104
    8      89
    9      67
    1      57
    6      37
    5      36
    10     29
    11     22
    13     14
    14     11
    12     10
    15      8
    16      7
    17      4
    18      2
    Name: YearsInCurrentRole, dtype: int64
    
    
    0     581
    1     357
    2     159
    7      76
    4      61
    3      52
    5      45
    6      32
    11     24
    8      18
    9      17
    15     13
    13     10
    12     10
    14      9
    10      6
    Name: YearsSinceLastPromotion, dtype: int64
    
    
    2     344
    0     263
    7     216
    3     142
    8     107
    4      98
    1      76
    9      64
    5      31
    6      29
    10     27
    11     22
    12     18
    13     14
    17      7
    15      5
    14      5
    16      2
    Name: YearsWithCurrManager, dtype: int64
    
    
    


```python
df.shape[0]
```




    1470




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>DailyRate</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>EnvironmentSatisfaction</th>
      <th>HourlyRate</th>
      <th>JobInvolvement</th>
      <th>JobLevel</th>
      <th>...</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>...</td>
      <td>1470.000000</td>
      <td>1470.0</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
      <td>1470.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>36.923810</td>
      <td>802.485714</td>
      <td>9.192517</td>
      <td>2.912925</td>
      <td>1.0</td>
      <td>1024.865306</td>
      <td>2.721769</td>
      <td>65.891156</td>
      <td>2.729932</td>
      <td>2.063946</td>
      <td>...</td>
      <td>2.712245</td>
      <td>80.0</td>
      <td>0.793878</td>
      <td>11.279592</td>
      <td>2.799320</td>
      <td>2.761224</td>
      <td>7.008163</td>
      <td>4.229252</td>
      <td>2.187755</td>
      <td>4.123129</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.135373</td>
      <td>403.509100</td>
      <td>8.106864</td>
      <td>1.024165</td>
      <td>0.0</td>
      <td>602.024335</td>
      <td>1.093082</td>
      <td>20.329428</td>
      <td>0.711561</td>
      <td>1.106940</td>
      <td>...</td>
      <td>1.081209</td>
      <td>0.0</td>
      <td>0.852077</td>
      <td>7.780782</td>
      <td>1.289271</td>
      <td>0.706476</td>
      <td>6.126525</td>
      <td>3.623137</td>
      <td>3.222430</td>
      <td>3.568136</td>
    </tr>
    <tr>
      <th>min</th>
      <td>18.000000</td>
      <td>102.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>30.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.000000</td>
      <td>80.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>30.000000</td>
      <td>465.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>1.0</td>
      <td>491.250000</td>
      <td>2.000000</td>
      <td>48.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>...</td>
      <td>2.000000</td>
      <td>80.0</td>
      <td>0.000000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>36.000000</td>
      <td>802.000000</td>
      <td>7.000000</td>
      <td>3.000000</td>
      <td>1.0</td>
      <td>1020.500000</td>
      <td>3.000000</td>
      <td>66.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>...</td>
      <td>3.000000</td>
      <td>80.0</td>
      <td>1.000000</td>
      <td>10.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>43.000000</td>
      <td>1157.000000</td>
      <td>14.000000</td>
      <td>4.000000</td>
      <td>1.0</td>
      <td>1555.750000</td>
      <td>4.000000</td>
      <td>83.750000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>4.000000</td>
      <td>80.0</td>
      <td>1.000000</td>
      <td>15.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>9.000000</td>
      <td>7.000000</td>
      <td>3.000000</td>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>60.000000</td>
      <td>1499.000000</td>
      <td>29.000000</td>
      <td>5.000000</td>
      <td>1.0</td>
      <td>2068.000000</td>
      <td>4.000000</td>
      <td>100.000000</td>
      <td>4.000000</td>
      <td>5.000000</td>
      <td>...</td>
      <td>4.000000</td>
      <td>80.0</td>
      <td>3.000000</td>
      <td>40.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>40.000000</td>
      <td>18.000000</td>
      <td>15.000000</td>
      <td>17.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 26 columns</p>
</div>




```python
sns.heatmap(df.isnull())
```




    <AxesSubplot:>




    
![png](output_67_1.png)
    



```python
print(df['Age'].value_counts())
ax= sns.countplot(x='Age',data=df)
plt.show()
```

    35    78
    34    77
    36    69
    31    69
    29    68
    32    61
    30    60
    33    58
    38    58
    40    57
    37    50
    27    48
    28    48
    42    46
    39    42
    45    41
    41    40
    26    39
    44    33
    46    33
    43    32
    50    30
    25    26
    24    26
    49    24
    47    24
    55    22
    51    19
    53    19
    48    19
    54    18
    52    18
    22    16
    56    14
    23    14
    58    14
    21    13
    20    11
    59    10
    19     9
    18     8
    60     5
    57     4
    Name: Age, dtype: int64
    


    
![png](output_68_1.png)
    



```python
print(df['DailyRate'].value_counts())
ax= sns.countplot(x='DailyRate',data=df)
plt.show()
```

    691     6
    408     5
    530     5
    1329    5
    1082    5
           ..
    650     1
    279     1
    316     1
    314     1
    628     1
    Name: DailyRate, Length: 886, dtype: int64
    


    
![png](output_69_1.png)
    



```python
print(df['DistanceFromHome'].value_counts())
ax= sns.countplot(x='DistanceFromHome',data=df)
plt.show()
```

    2     211
    1     208
    10     86
    9      85
    3      84
    7      84
    8      80
    5      65
    4      64
    6      59
    16     32
    11     29
    24     28
    23     27
    29     27
    15     26
    18     26
    26     25
    25     25
    20     25
    28     23
    19     22
    14     21
    12     20
    17     20
    22     19
    13     19
    21     18
    27     12
    Name: DistanceFromHome, dtype: int64
    


    
![png](output_70_1.png)
    



```python
print(df['Education'].value_counts())
ax= sns.countplot(x='Education',data=df)
plt.show()
```

    3    572
    4    398
    2    282
    1    170
    5     48
    Name: Education, dtype: int64
    


    
![png](output_71_1.png)
    



```python
print(df['EmployeeCount'].value_counts())
ax= sns.countplot(x='EmployeeCount',data=df)
plt.show()
```

    1    1470
    Name: EmployeeCount, dtype: int64
    


    
![png](output_72_1.png)
    



```python
print(df['EmployeeNumber'].value_counts())
ax= sns.countplot(x='EmployeeNumber',data=df)
plt.show()
```

    1       1
    1391    1
    1389    1
    1387    1
    1383    1
           ..
    659     1
    657     1
    656     1
    655     1
    2068    1
    Name: EmployeeNumber, Length: 1470, dtype: int64
    


    
![png](output_73_1.png)
    



```python
print(df['EnvironmentSatisfaction'].value_counts())
ax= sns.countplot(x='EnvironmentSatisfaction',data=df)
plt.show()
```

    3    453
    4    446
    2    287
    1    284
    Name: EnvironmentSatisfaction, dtype: int64
    


    
![png](output_74_1.png)
    



```python
print(df['HourlyRate'].value_counts())
ax= sns.countplot(x='HourlyRate',data=df)
plt.show()
```

    66    29
    98    28
    42    28
    48    28
    84    28
          ..
    31    15
    53    14
    68    14
    38    13
    34    12
    Name: HourlyRate, Length: 71, dtype: int64
    


    
![png](output_75_1.png)
    



```python
print(df['JobInvolvement'].value_counts())
ax= sns.countplot(x='JobInvolvement',data=df)
plt.show()
```

    3    868
    2    375
    4    144
    1     83
    Name: JobInvolvement, dtype: int64
    


    
![png](output_76_1.png)
    



```python
print(df['JobLevel'].value_counts())
ax= sns.countplot(x='JobLevel',data=df)
plt.show()
```

    1    543
    2    534
    3    218
    4    106
    5     69
    Name: JobLevel, dtype: int64
    


    
![png](output_77_1.png)
    



```python
print(df['RelationshipSatisfaction'].value_counts())
ax= sns.countplot(x='RelationshipSatisfaction',data=df)
plt.show()
```

    3    459
    4    432
    2    303
    1    276
    Name: RelationshipSatisfaction, dtype: int64
    


    
![png](output_78_1.png)
    



```python
print(df['StandardHours'].value_counts())
ax= sns.countplot(x='StandardHours',data=df)
plt.show()
```

    80    1470
    Name: StandardHours, dtype: int64
    


    
![png](output_79_1.png)
    



```python
print(df['StockOptionLevel'].value_counts())
ax= sns.countplot(x='StockOptionLevel',data=df)
plt.show()
```

    0    631
    1    596
    2    158
    3     85
    Name: StockOptionLevel, dtype: int64
    


    
![png](output_80_1.png)
    



```python
print(df['TotalWorkingYears'].value_counts())
ax= sns.countplot(x='TotalWorkingYears',data=df)
plt.show()
```

    10    202
    6     125
    8     103
    9      96
    5      88
    7      81
    1      81
    4      63
    12     48
    3      42
    15     40
    16     37
    11     36
    13     36
    21     34
    17     33
    2      31
    14     31
    20     30
    18     27
    19     22
    23     22
    22     21
    24     18
    25     14
    28     14
    26     14
    0      11
    29     10
    31      9
    32      9
    30      7
    33      7
    27      7
    36      6
    34      5
    37      4
    35      3
    40      2
    38      1
    Name: TotalWorkingYears, dtype: int64
    


    
![png](output_81_1.png)
    



```python
print(df['TrainingTimesLastYear'].value_counts())
ax= sns.countplot(x='TrainingTimesLastYear',data=df)
plt.show()
```

    2    547
    3    491
    4    123
    5    119
    1     71
    6     65
    0     54
    Name: TrainingTimesLastYear, dtype: int64
    


    
![png](output_82_1.png)
    



```python
print(df['WorkLifeBalance'].value_counts())
ax= sns.countplot(x='WorkLifeBalance',data=df)
plt.show()
```

    3    893
    2    344
    4    153
    1     80
    Name: WorkLifeBalance, dtype: int64
    


    
![png](output_83_1.png)
    



```python
print(df['YearsAtCompany'].value_counts())
ax= sns.countplot(x='YearsAtCompany',data=df)
plt.show()
```

    5     196
    1     171
    3     128
    2     127
    10    120
    4     110
    7      90
    9      82
    8      80
    6      76
    0      44
    11     32
    20     27
    13     24
    15     20
    14     18
    22     15
    12     14
    21     14
    18     13
    16     12
    19     11
    17      9
    24      6
    33      5
    25      4
    26      4
    31      3
    32      3
    27      2
    36      2
    29      2
    23      2
    37      1
    40      1
    34      1
    30      1
    Name: YearsAtCompany, dtype: int64
    


    
![png](output_84_1.png)
    



```python
print(df['YearsInCurrentRole'].value_counts())
ax= sns.countplot(x='YearsInCurrentRole',data=df)
plt.show()
```

    2     372
    0     244
    7     222
    3     135
    4     104
    8      89
    9      67
    1      57
    6      37
    5      36
    10     29
    11     22
    13     14
    14     11
    12     10
    15      8
    16      7
    17      4
    18      2
    Name: YearsInCurrentRole, dtype: int64
    


    
![png](output_85_1.png)
    



```python
print(df['YearsSinceLastPromotion'].value_counts())
ax= sns.countplot(x='YearsSinceLastPromotion',data=df)
plt.show()
```

    0     581
    1     357
    2     159
    7      76
    4      61
    3      52
    5      45
    6      32
    11     24
    8      18
    9      17
    15     13
    13     10
    12     10
    14      9
    10      6
    Name: YearsSinceLastPromotion, dtype: int64
    


    
![png](output_86_1.png)
    



```python
print(df['YearsWithCurrManager'].value_counts())
ax= sns.countplot(x='YearsWithCurrManager',data=df)
plt.show()
```

    2     344
    0     263
    7     216
    3     142
    8     107
    4      98
    1      76
    9      64
    5      31
    6      29
    10     27
    11     22
    12     18
    13     14
    17      7
    15      5
    14      5
    16      2
    Name: YearsWithCurrManager, dtype: int64
    


    
![png](output_87_1.png)
    



```python

```
